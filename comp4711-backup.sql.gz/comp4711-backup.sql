-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 29, 2015 at 10:56 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `comp4711`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('12b4c36d909b90983b0d50ec34fa45505c8f8c46', '127.0.0.1', 1447651408, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373635313137393b),
('2062c6ca576431fd5b6c5cad4b2be813c8dcfb72', '127.0.0.1', 1447649382, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373634393038343b),
('3fdf1e8fce1717198852e23b6ad4b82c4d32627a', '127.0.0.1', 1447653717, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373635333536343b),
('6dbdf372e99729335e5745232bf92335f6556d2d', '127.0.0.1', 1447809499, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373830393430383b706c617965725f646174617c613a393a7b733a323a226964223b733a323a223437223b733a373a227375726e616d65223b733a393a22576869746568656164223b733a393a2266697273746e616d65223b733a353a224c75636b79223b733a363a226a6572736579223b733a323a223133223b733a383a22706f736974696f6e223b733a323a225752223b733a363a22776569676874223b733a333a22313633223b733a333a22616765223b733a323a223233223b733a373a22636f6c6c656765223b733a31363a22466c6f726964612041746c616e746963223b733a333a226d7567223b733a31393a227768697465686561645f6c75636b792e6a7067223b7d),
('6e3c93a88f46dacee259c9990a5be4310c851734', '127.0.0.1', 1447648245, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373634373936303b),
('6e60d451456870873b4fee7a3d42ad646a05b25d', '127.0.0.1', 1447649961, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373634393935363b),
('77917d0135a2a168c9c400ce309ee03a6c68883d', '127.0.0.1', 1447645063, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373634343839353b),
('8f909408d8e0e316341eb3beca63b61be98fac79', '127.0.0.1', 1447650372, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373635303038303b),
('98ca53efbb5b51b898b14b0ab51673e1a9a43503', '127.0.0.1', 1447644350, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373634343333393b),
('c90f1a9c8feb92921344a303386ece1b35abae76', '127.0.0.1', 1447650629, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373635303532373b706c617965725f646174617c613a393a7b733a323a226964223b4e3b733a373a227375726e616d65223b733a303a22223b733a393a2266697273746e616d65223b733a303a22223b733a363a226a6572736579223b733a303a22223b733a383a22706f736974696f6e223b733a303a22223b733a363a22776569676874223b733a303a22223b733a333a22616765223b733a303a22223b733a373a22636f6c6c656765223b733a303a22223b733a333a226d7567223b733a32353a2264656661756c745f70726f66696c655f696d6167652e706e67223b7d),
('e8d2c8e65e4b86cfc57500e49022d68047c5a087', '127.0.0.1', 1447650033, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373634393735323b),
('ed6a48762b417fcf1b1fac28a12cdcb68a92f7c7', '127.0.0.1', 1447649723, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373634393432333b),
('fe95725b5f2fa777ee56b1578f9d2ab20de74ce6', '127.0.0.1', 1447648715, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373634383632393b),
('76551a6fb4ce90674f2f69e15efe04878818bab0', '127.0.0.1', 1448576329, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383537363037303b706c617965725f646174617c613a393a7b733a323a226964223b733a323a223437223b733a373a227375726e616d65223b733a393a22576869746568656164223b733a393a2266697273746e616d65223b733a353a224c75636b79223b733a363a226a6572736579223b733a323a223133223b733a383a22706f736974696f6e223b733a323a225752223b733a363a22776569676874223b733a333a22313633223b733a333a22616765223b733a323a223233223b733a373a22636f6c6c656765223b733a31363a22466c6f726964612041746c616e746963223b733a333a226d7567223b733a31393a227768697465686561645f6c75636b792e6a7067223b7d),
('268999d73f02e9e377a42193b4405a4b869248b2', '127.0.0.1', 1448576430, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383537363432393b706c617965725f646174617c613a393a7b733a323a226964223b733a323a223437223b733a373a227375726e616d65223b733a393a22576869746568656164223b733a393a2266697273746e616d65223b733a353a224c75636b79223b733a363a226a6572736579223b733a323a223133223b733a383a22706f736974696f6e223b733a323a225752223b733a363a22776569676874223b733a333a22313633223b733a333a22616765223b733a323a223233223b733a373a22636f6c6c656765223b733a31363a22466c6f726964612041746c616e746963223b733a333a226d7567223b733a31393a227768697465686561645f6c75636b792e6a7067223b7d),
('af72e33093b5cb71f45f7e7c9589fcd2d73912da', '127.0.0.1', 1448578156, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383537383135343b706c617965725f646174617c613a393a7b733a323a226964223b733a323a223437223b733a373a227375726e616d65223b733a393a22576869746568656164223b733a393a2266697273746e616d65223b733a353a224c75636b79223b733a363a226a6572736579223b733a323a223133223b733a383a22706f736974696f6e223b733a323a225752223b733a363a22776569676874223b733a333a22313633223b733a333a22616765223b733a323a223233223b733a373a22636f6c6c656765223b733a31363a22466c6f726964612041746c616e746963223b733a333a226d7567223b733a31393a227768697465686561645f6c75636b792e6a7067223b7d),
('a52cc89e9e5d2a52f314e4493d1c67f570915421', '127.0.0.1', 1448579142, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383537383836303b706c617965725f646174617c613a393a7b733a323a226964223b733a323a223437223b733a373a227375726e616d65223b733a393a22576869746568656164223b733a393a2266697273746e616d65223b733a353a224c75636b79223b733a363a226a6572736579223b733a323a223133223b733a383a22706f736974696f6e223b733a323a225752223b733a363a22776569676874223b733a333a22313633223b733a333a22616765223b733a323a223233223b733a373a22636f6c6c656765223b733a31363a22466c6f726964612041746c616e746963223b733a333a226d7567223b733a31393a227768697465686561645f6c75636b792e6a7067223b7d),
('d3cf36bcac2e8e11bbf18f2d37408a9b2267a4dd', '127.0.0.1', 1448579420, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383537393232393b706c617965725f646174617c613a393a7b733a323a226964223b733a323a223437223b733a373a227375726e616d65223b733a393a22576869746568656164223b733a393a2266697273746e616d65223b733a353a224c75636b79223b733a363a226a6572736579223b733a323a223133223b733a383a22706f736974696f6e223b733a323a225752223b733a363a22776569676874223b733a333a22313633223b733a333a22616765223b733a323a223233223b733a373a22636f6c6c656765223b733a31363a22466c6f726964612041746c616e746963223b733a333a226d7567223b733a31393a227768697465686561645f6c75636b792e6a7067223b7d),
('a5010bec8548c8b94b3b1c67edee1d0f170a26a5', '127.0.0.1', 1448579770, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383537393737303b706c617965725f646174617c613a393a7b733a323a226964223b733a323a223437223b733a373a227375726e616d65223b733a393a22576869746568656164223b733a393a2266697273746e616d65223b733a353a224c75636b79223b733a363a226a6572736579223b733a323a223133223b733a383a22706f736974696f6e223b733a323a225752223b733a363a22776569676874223b733a333a22313633223b733a333a22616765223b733a323a223233223b733a373a22636f6c6c656765223b733a31363a22466c6f726964612041746c616e746963223b733a333a226d7567223b733a31393a227768697465686561645f6c75636b792e6a7067223b7d),
('fdaa10ad3a52df285ad087b51a3bab6ac338d934', '127.0.0.1', 1448592886, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383539323539373b706c617965725f646174617c613a393a7b733a323a226964223b733a323a223437223b733a373a227375726e616d65223b733a393a22576869746568656164223b733a393a2266697273746e616d65223b733a353a224c75636b79223b733a363a226a6572736579223b733a323a223133223b733a383a22706f736974696f6e223b733a323a225752223b733a363a22776569676874223b733a333a22313633223b733a333a22616765223b733a323a223233223b733a373a22636f6c6c656765223b733a31363a22466c6f726964612041746c616e746963223b733a333a226d7567223b733a31393a227768697465686561645f6c75636b792e6a7067223b7d),
('870c1c919ee765e0e76ab676dd5aa478c57e8262', '127.0.0.1', 1448766257, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383736353935373b),
('82db34f9fda2d0a33d002d99e3a7d6b12daaa51c', '127.0.0.1', 1448766273, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383736363236373b),
('323959651e2a89c4b1653187ef49769d908f10a0', '127.0.0.1', 1448766434, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383736363237333b),
('508776b1767d767b0c3df3d924748cb8ec8e5a7d', '127.0.0.1', 1448766840, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383736363538353b),
('c5944f95371fb115fcae0df5fa4777a0fb050b04', '127.0.0.1', 1448827867, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383832373638343b),
('f8dbc8091676ae7fccf67a55741352293dc7f027', '127.0.0.1', 1448827996, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383832373939303b),
('788234028af7787af79996f81b273082edef38a2', '127.0.0.1', 1448829195, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383832393139343b),
('c5f76565768fc3b2557d9d8df5a38f3eea461981', '127.0.0.1', 1448829845, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383832393534343b),
('e4af7f7ed950bcb7e4b2c531dbc921a690418c24', '127.0.0.1', 1448830131, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383832393838373b),
('d6c4ecea8749071e73c9a2d8e84987f27ac71be2', '127.0.0.1', 1448830260, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383833303236303b),
('1dfde23ee3f64dfbe0cf014f6ebcaad4bc90b6f5', '127.0.0.1', 1448830812, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383833303831323b),
('c0f1225898dccf5614863fac5a05668beabdc941', '127.0.0.1', 1448831426, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383833313234303b),
('eccd509f818c54564a7cb7ff99acb816e6f7a514', '127.0.0.1', 1448831568, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383833313536383b),
('f536c8ccfc8648240c785e182e63f3448c28ec9a', '127.0.0.1', 1448832399, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383833323231373b),
('21c2c1aba3026d9fd2c2f040724a131affa7a856', '127.0.0.1', 1448833275, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383833333031353b),
('936c15b31900dd9e6a6bb234ade72b0b7b5dcd48', '127.0.0.1', 1448833599, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383833333333323b),
('26d0443563085c5770ab93a911d73824f751a5dd', '127.0.0.1', 1448833997, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383833333939373b);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
CREATE TABLE IF NOT EXISTS `history` (
  `home` varchar(3) NOT NULL,
  `away` varchar(3) NOT NULL,
  `score` varchar(5) NOT NULL,
  `date` varchar(8) NOT NULL,
  `inserted` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`home`, `away`, `score`, `date`, `inserted`) VALUES
('NE', 'PIT', '21:28', '20150910', '2015-11-29 13:55:24'),
('DAL', 'NE', '21:28', '20150911', '2015-11-29 13:55:24');

-- --------------------------------------------------------

--
-- Table structure for table `league`
--

DROP TABLE IF EXISTS `league`;
CREATE TABLE IF NOT EXISTS `league` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `city` varchar(64) NOT NULL,
  `conference` varchar(64) NOT NULL,
  `division` varchar(64) NOT NULL,
  `filename` varchar(256) NOT NULL,
  `code` varchar(3) NOT NULL,
  `wins` int(3) NOT NULL,
  `losses` int(3) NOT NULL,
  `ties` int(3) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `league`
--

INSERT INTO `league` (`id`, `name`, `city`, `conference`, `division`, `filename`, `code`, `wins`, `losses`, `ties`) VALUES
(1, 'New England Patriots', 'New England', 'American Football Conference', 'AFC East', 'ne.jpg', 'NE', 3, 0, 0),
(2, 'Buffalo Bills', 'Buffalo', 'American Football Conference', 'AFC East', 'buf.jpg', 'BUF', 3, 0, 0),
(3, 'New York Jets', 'New York', 'American Football Conference', 'AFC East', 'nyj.jpg', 'NYJ', 3, 0, 0),
(4, 'Miami Dolphins', 'Miami', 'American Football Conference', 'AFC East', 'mia.jpg', 'MIA', 3, 0, 0),
(5, 'Cincinatti Bengals', 'New Jersey', 'American Football Conference', 'AFC North', 'cin.jpg', 'CIN', 3, 0, 0),
(6, 'Pittsburgh Steelers', 'Pittsburgh', 'American Football Conference', 'AFC North', 'pit.jpg', 'PIT', 3, 0, 0),
(7, 'Cleveland Browns', 'Cleveland', 'American Football Conference', 'AFC North', 'cle.jpg', 'CLE', 3, 0, 0),
(8, 'Baltimore Ravens', 'Baltimore', 'American Football Conference', 'AFC North', 'bal.jpg', 'BAL', 3, 0, 0),
(9, 'Indianapolis Colts', 'Indianapolis', 'American Football Conference', 'AFC South', 'ind.jpg', 'IND', 3, 0, 0),
(10, 'Tennesee Titans', 'Tennesee', 'American Football Conference', 'AFC South', 'ten.jpg', 'TEN', 3, 0, 0),
(11, 'Houston Texans', 'Houston', 'American Football Conference', 'AFC South', 'hou.jpg', 'HOU', 3, 0, 0),
(12, 'Jackson Jaguars', 'Jackson', 'American Football Conference', 'AFC South', 'jac.jpg', 'JAC', 3, 0, 0),
(13, 'Denver Broncos', 'Denver', 'American Football Conference', 'AFC West', 'den.jpg', 'DEN', 3, 0, 0),
(14, 'Oakland Raiders', 'Oakland', 'American Football Conference', 'AFC West', 'oak.jpg', 'OAK', 3, 0, 0),
(15, 'Kansas City Chiefs', 'Kansas', 'American Football Conference', 'AFC West', 'kc.jpg', 'KC', 3, 0, 0),
(16, 'San Diego Chargers', 'San Diego', 'American Football Conference', 'AFC West', 'sd.jpg', 'SD', 3, 0, 0),
(17, 'Dallas Cowboys', 'Dallas', 'National Football Conference', 'NFC East', 'dal.jpg', 'DAL', 3, 0, 0),
(18, 'New York Giants', 'New York Giants', 'National Football Conference', 'NFC East', 'nyg.jpg', 'NYG', 3, 0, 0),
(19, 'Washington Redskins', 'Washington', 'National Football Conference', 'NFC East', 'was.jpg', 'WAS', 3, 0, 0),
(20, 'Philadephia Eagles', 'Philadelphia', 'National Football Conference', 'NFC East', 'phi.jpg', 'PHI', 3, 0, 0),
(21, 'Green Bay Packers', 'Green Bay', 'National Football Conference', 'NFC North', 'gb.jpg', 'GB', 3, 0, 0),
(22, 'Minnesota Vikings', 'Minnesota', 'National Football Conference', 'NFC North', 'min.jpg', 'MIN', 3, 0, 0),
(23, 'Detroit Lions', 'Detroit', 'National Football Conference', 'NFC North', 'det.jpg', 'DET', 3, 0, 0),
(24, 'Chicago Bears', 'Chicago', 'National Football Conference', 'NFC North', 'chi.jpg', 'CHI', 3, 0, 0),
(25, 'Carolina Panthers', 'Carolina', 'National Football Conference', 'NFC South', 'car.jpg', 'CAR', 3, 0, 0),
(26, 'Atlanta Falcons', 'Atlanta', 'National Football Conference', 'NFC South', 'atl.jpg', 'ATL', 3, 0, 0),
(27, 'Tampa Bay Buccaneers', 'Tampa Bay', 'National Football Conference', 'NFC South', 'tb.jpg', 'TB', 3, 0, 0),
(28, 'New Orleans Saints', 'New Orleans', 'National Football Conference', 'NFC South', 'no.jpg', 'NO', 3, 0, 0),
(29, 'Arizona Cardinals', 'Arizona', 'National Football Conference', 'NFC West', 'ari.jpg', 'ARI', 3, 0, 0),
(30, 'St. Louis Panthers', 'St. Louis', 'National Football Conference', 'NFC West', 'stl.jpg', 'STL', 3, 0, 0),
(31, 'San Francisco 49ers', 'San Francisco', 'National Football Conference', 'NFC West', 'sf.jpg', 'SF', 3, 0, 0),
(32, 'Seattle Seahawks', 'Seattle', 'National Football Conference', 'NFC West', 'sea.jpg', 'SEA', 3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
CREATE TABLE IF NOT EXISTS `players` (
  `id` int(11) NOT NULL,
  `surname` varchar(64) NOT NULL,
  `firstname` varchar(64) NOT NULL,
  `jersey` int(3) NOT NULL,
  `position` varchar(2) NOT NULL,
  `weight` int(3) NOT NULL,
  `age` int(3) NOT NULL,
  `college` varchar(64) NOT NULL,
  `mug` varchar(256) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`id`, `surname`, `firstname`, `jersey`, `position`, `weight`, `age`, `college`, `mug`) VALUES
(1, 'Bailey', 'Dan', 5, 'K', 195, 27, 'Oklahoma State', 'bailey_dan.jpg'),
(2, 'Beasley', 'Cole', 11, 'WR', 180, 26, 'Southern Methodist', 'beasley_cole.jpg'),
(3, 'Bernadeau', 'Mackenzy', 73, 'G', 322, 29, 'Bentley', 'bernadeau_mackenzy.jpg'),
(4, 'Brown', 'Charles', 78, 'OL', 297, 28, 'USC', 'brown_charles.jpg'),
(5, 'Bryant', 'Dez', 88, 'WR', 220, 26, 'Oklahoma State', 'bryant_dez.jpg'),
(6, 'Butler', 'Brice', 19, 'WR', 215, 25, 'San Diego State', 'butler_brice.jpg'),
(7, 'Carr', 'Brandon', 39, 'CB', 210, 29, 'Grand Valley State', 'carr_brandon.jpg'),
(8, 'Cassel', 'Matt', 16, 'QB', 228, 33, 'USC', 'cassel_matt.jpg'),
(9, 'Church', 'Barry', 42, 'S', 218, 27, 'Toledo', 'church_barry.jpg'),
(10, 'Claiborne', 'Morris', 24, 'CB', 192, 25, 'LSU', 'claiborne_morris.jpg'),
(11, 'Clutts', 'Tyler', 44, 'FB', 250, 30, 'Fresno State', 'clutts_tyler.jpg'),
(12, 'Collins', 'Lael', 71, 'OL', 321, 22, 'Louisiana State University - Shreveport', 'collins_lael.jpg'),
(13, 'Crawford', 'Jack', 58, 'DE', 288, 27, 'Penn State', 'crawford_jack.jpg'),
(14, 'Crawford', 'Tyrone', 98, 'DT', 285, 25, 'Boise State', 'crawford_tyrone.jpg'),
(15, 'Dunbar', 'Lance', 25, 'RB', 195, 25, 'North Texas', 'dunbar_lance.jpg'),
(16, 'Escobar', 'Gavin', 89, 'TE', 260, 24, 'San Diego State', 'escobar_gavin.jpg'),
(17, 'Frederick', 'Travis', 72, 'C', 315, 24, 'Wisconsin', 'frederick_travis.jpg'),
(18, 'Free', 'Doug', 68, 'OT', 325, 31, 'Northern Illinois', 'free_doug.jpg'),
(19, 'Gachkar', 'Andrew', 52, 'LB', 224, 26, 'Missouri', 'gachkar_andrew.jpg'),
(20, 'Green', 'Chaz', 79, 'OL', 300, 23, 'Florida', 'green_chaz.jpg'),
(21, 'Gregory', 'Randy', 94, 'DE', 245, 22, 'Nebraska', 'gregory_randy.jpg'),
(22, 'Hanna', 'James', 84, 'TE', 260, 26, 'Oklahoma', 'hanna_james.jpg'),
(23, 'Hayden', 'Nick', 96, 'DT', 303, 29, 'Wisconsin', 'hayden_nick.jpg'),
(24, 'Heath', 'Jeff', 38, 'S', 212, 24, 'Saginaw Valley State', 'heath_jeff.jpg'),
(25, 'Hitchens', 'Anthony', 59, 'LB', 235, 23, 'Iowa', 'hitchens_anthony.jpg'),
(26, 'Irving', 'David', 95, 'DL', 273, 22, 'Iowa State', 'irving_david.jpg'),
(27, 'Jones', 'Byron', 31, 'CB', 199, 23, 'Connecticut', 'jones_byron.jpg'),
(28, 'Jones', 'Chris', 6, 'P', 205, 26, 'Carson-Newman', 'jones_chris.jpg'),
(29, 'LaDouceur', 'L.P.', 91, 'LS', 256, 34, 'California', 'ladouceur_lp.jpg'),
(30, 'Lawrence', 'DeMarcus', 90, 'DE', 251, 23, 'Boise State', 'lawrence_demarcus.jpg'),
(31, 'Leary', 'Ronald', 65, 'G', 320, 26, 'Memphis', 'leary_ronald.jpg'),
(32, 'Lee', 'Sean', 50, 'LB', 238, 29, 'Penn State', 'lee_sean.jpg'),
(33, 'Martin', 'Zack', 70, 'G', 310, 24, 'Notre Dame', 'martin_zack.jpg'),
(34, 'McCray', 'Danny', 40, 'S', 221, 27, 'LSU', 'mccray_danny.jpg'),
(35, 'McFadden', 'Darren', 20, 'RB', 210, 28, 'Arkansas', 'mcfadden_darren.jpg'),
(36, 'Michael', 'Christine', 30, 'RB', 221, 24, 'Texas A&M', 'michael_christine.jpg'),
(37, 'Mincey', 'Jeremy', 92, 'DE', 280, 31, 'Florida', 'mincey_jeremy.jpg'),
(38, 'Moore', 'Kellen', 17, 'QB', 200, 26, 'Boise State', 'moore_kellen.jpg'),
(39, 'Patmon', 'Tyler', 26, 'CB', 185, 24, 'Oklahoma State', 'patmon_tyler.jpg'),
(40, 'Russell', 'Ryan', 99, 'DE', 267, 23, 'Purdue', 'russell_ryan.jpg'),
(41, 'Smith', 'Keith', 56, 'LB', 232, 23, 'San Jose State', 'smith_keith.jpg'),
(42, 'Smith', 'Tyron', 77, 'OT', 320, 24, 'USC', 'smith_tyron.jpg'),
(43, 'Street', 'Devin', 15, 'WR', 200, 24, 'Pittsburgh', 'street_devin.jpg'),
(44, 'Swaim', 'Geoff', 87, 'TE', 250, 22, 'Texas', 'swaim_geoff.jpg'),
(45, 'Weeden', 'Brandon', 3, 'QB', 228, 31, 'Oklahoma State', 'weeden_brandon.jpg'),
(46, 'White', 'Corey', 23, 'CB', 206, 25, 'Samford', 'white_corey.jpg'),
(47, 'Whitehead', 'Lucky', 13, 'WR', 163, 23, 'Florida Atlantic', 'whitehead_lucky.jpg'),
(48, 'Wilber', 'Kyle', 51, 'LB', 245, 26, 'Wake Forest', 'wilber_kyle.jpg'),
(49, 'Wilcox', 'J.J.', 27, 'S', 212, 24, 'Georgia Southern', 'wilcox_jj.jpg'),
(50, 'Williams', 'Terrance', 83, 'WR', 208, 26, 'Baylor', 'williams_terrance.jpg'),
(51, 'Williams', 'Trey', 28, 'RB', 195, 22, 'Texas A&M', 'williams_trey.jpg'),
(52, 'Wilson', 'Damien', 57, 'LB', 243, 22, 'Minnesota', 'wilson_damien.jpg'),
(53, 'Witten', 'Jason', 82, 'TE', 263, 33, 'Tennessee', 'witten_jason.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`date`,`home`);

--
-- Indexes for table `league`
--
ALTER TABLE `league`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `league`
--
ALTER TABLE `league`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
